import Navbar from '../components/Navbar';
import OpportunityCard from '../components/OpportunityCard';
import { opportunities } from '../data/opportunities';

export default function HomePage() {
  return (
    <main className="min-h-screen bg-black text-white">
      <Navbar />

      <section className="max-w-7xl mx-auto px-6 py-20">
        <h1 className="text-6xl font-bold max-w-3xl leading-tight">
          Discover your next global opportunity
        </h1>

        <p className="text-white/70 mt-6 text-lg max-w-2xl">
          Scholarships, summer programs and international opportunities for students.
        </p>
      </section>

      <section className="max-w-7xl mx-auto px-6 pb-20">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {opportunities.map((opportunity) => (
            <OpportunityCard
              key={opportunity.title}
              {...opportunity}
            />
          ))}
        </div>
      </section>
    </main>
  );
}
