import './globals.css';

export const metadata = {
  title: 'Dream High',
  description: 'International academic opportunities platform',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
