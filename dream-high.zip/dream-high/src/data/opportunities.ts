export const opportunities = [
  {
    title: 'Yale Young Global Scholars',
    country: 'United States',
    funding: 'Partial Scholarship',
    days: 8,
    category: 'Summer Program',
  },
  {
    title: 'UWC Scholarship Program',
    country: 'Global',
    funding: 'Fully Funded',
    days: 14,
    category: 'Scholarship',
  },
];
