export default function Navbar() {
  return (
    <header className="p-6 border-b border-white/10 flex justify-between items-center">
      <h1 className="text-2xl font-bold">
        Dream <span className="text-purple-400">High</span>
      </h1>

      <nav className="flex gap-6">
        <a href="#">Home</a>
        <a href="#">Opportunities</a>
        <a href="#">About</a>
      </nav>
    </header>
  );
}
