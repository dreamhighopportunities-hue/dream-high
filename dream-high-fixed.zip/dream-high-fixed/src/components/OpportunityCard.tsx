type Props = {
  title: string
  country: string
  funding: string
  days: number
  category: string
}

export default function OpportunityCard({
  title,
  country,
  funding,
  days,
  category,
}: Props) {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
      <span className="text-purple-400 text-sm">
        {category}
      </span>

      <h2 className="text-2xl font-bold mt-3">
        {title}
      </h2>

      <p className="text-white/60 mt-2">
        {country}
      </p>

      <div className="mt-4">
        <span className="text-green-400 text-sm">
          {funding}
        </span>
      </div>

      <div className="mt-6 p-4 rounded-2xl bg-purple-500/10">
        ⏳ {days} Days Remaining
      </div>

      <button className="w-full mt-6 py-3 rounded-2xl bg-gradient-to-r from-purple-500 to-blue-500">
        View Opportunity
      </button>
    </div>
  )
}
