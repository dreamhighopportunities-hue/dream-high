export default function Navbar() {
  return (
    <header className="border-b border-white/10 p-6 flex justify-between items-center">
      <h1 className="text-2xl font-bold">
        Dream <span className="text-purple-400">High</span>
      </h1>

      <nav className="flex gap-6 text-white/80">
        <a href="#">Home</a>
        <a href="#">Opportunities</a>
        <a href="#">About</a>
      </nav>
    </header>
  )
}
