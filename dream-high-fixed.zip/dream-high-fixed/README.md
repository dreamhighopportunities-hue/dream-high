# Dream High

Modern platform for international academic opportunities.

## Run locally

```bash
npm install
npm run dev
```

Open:

http://localhost:3000
